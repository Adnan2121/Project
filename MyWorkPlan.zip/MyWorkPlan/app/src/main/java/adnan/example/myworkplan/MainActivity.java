package adnan.example.myworkplan;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

        ViewPager view_pager_Activity;
        ArrayList<Integer>arrayList = new ArrayList<>();
        Button loc_btn,task_btn,rep_btn,track_btn,other_btn;
        MenuView.ItemView action_logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        view_pager_Activity = findViewById(R.id.view_pager_Activity);
        arrayList.add(R.drawable.plan_flow);
        arrayList.add(R.drawable.planning_chart);
        arrayList.add(R.drawable.timeline);
        arrayList.add(R.drawable.pak);
        Image_Slider_Adapter slider_adapter = new Image_Slider_Adapter(getApplicationContext(),arrayList);
        view_pager_Activity.setAdapter(slider_adapter);
        loc_btn = findViewById(R.id.loc_btn);
        task_btn = findViewById(R.id.task_btn);
        rep_btn = findViewById(R.id.rep_btn);
        track_btn = findViewById(R.id.track_btn);
        other_btn = findViewById(R.id.other_btn);
        loc_btn.setOnClickListener(this);
        task_btn.setOnClickListener(this);
        rep_btn.setOnClickListener(this);
        track_btn.setOnClickListener(this);
        other_btn.setOnClickListener(this);

        action_logout = findViewById(R.id.action_logout);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.action_settings) {
            Toast.makeText(this, "Setting", Toast.LENGTH_SHORT).show();
            return true;
        }
        else if (id == R.id.action_logout){
            Toast.makeText(this, "Your are logout", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_Home) {
            // Handle the camera action
        } else if (id == R.id.nav_Location_Remainder) {
            Intent intent = new Intent(getApplicationContext(),LocationRemainder.class);
            startActivity(intent);

        } else if (id == R.id.nav_task_remainder) {
            Intent intent = new Intent(getApplicationContext(),Task_ListView.class);
            startActivity(intent);


        } else if (id == R.id.nav_others) {

        } else if (id == R.id.nav_faq) {

        } else if (id == R.id.nav_about) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.loc_btn:
            {
                Toast.makeText(this, "Location Button Active", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.task_btn:
            {
                Toast.makeText(this, "Task Button Active", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.rep_btn:
            {
                Toast.makeText(this, "Remainder Button Active", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.track_btn:
            {
                Toast.makeText(this, "Track Button Active", Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.other_btn:
            {
                Toast.makeText(this, "Others Button Active", Toast.LENGTH_SHORT).show();
                break;
            }
        }

    }

}
